from .api import VoiceAPI

__all__ = ['VoiceAPI']
__version__ = '1.0.0'