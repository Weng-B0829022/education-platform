from .video_generator import HeyGenVideoGenerator

__all__ = ['HeyGenVideoGenerator']
__version__ = "1.0.0"
