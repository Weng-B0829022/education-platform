from .video_generator import FullBodyAvatarGenerator

__all__ = ['FullBodyAvatarGenerator']
__version__ = "1.0.0"
