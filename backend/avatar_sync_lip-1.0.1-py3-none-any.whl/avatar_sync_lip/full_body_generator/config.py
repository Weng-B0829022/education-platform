ALLOWED_CHARACTERS = [
    "man1", "man2", "woman1", "woman2"
]
